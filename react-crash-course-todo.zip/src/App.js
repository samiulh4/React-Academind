import Todo from "./components/Todo";

function App() {
    return (
        <div>
            <h1>My Todo</h1>
            <Todo text="Learn React js"/>
            <Todo text="Learn Vue Js"/>
            <Todo text="Learn Angular Js"/>
        </div>);
}

export default App;
